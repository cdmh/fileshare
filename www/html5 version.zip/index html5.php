<?phprequire_once './library/stdhdr.php';
require_once "library/alphaID.inc.php";// Test the pyf.li HTTD process is running$pyfli = 'http://localhost:8089/';
$res = curl_init($pyfli);
curl_setopt($res, CURLOPT_NOBODY, true);
curl_setopt($res, CURLOPT_FOLLOWLOCATION, true);
curl_exec($res);
$service_available = (curl_getinfo($res, CURLINFO_HTTP_CODE) == 200);
curl_close($res);
// Query Progress request proxyif (isset($_GET['query_progress'])){    if ($service_available)    {        $res = @curl_init("http://localhost:8089/?query_progress={$_GET['query_progress']}");        @curl_setopt($res, CURLOPT_URL, "http://localhost:8089/?query_progress={$_GET['query_progress']}");        curl_exec($res);        @curl_close($res);    }    else        echo "{\"version\":1,error:\"The service is currently unavailable.\"}";
    exit;}/**************************$result = $this->db_query("INSERT INTO pyfli_files (content_type,content_length,original_filename,local_pathname) VALUES ('?');", $long);
if ($result === FALSE)
    unset($link);
else
{
    $id = mysql_insert_id($this->_db_connection);
    $link = alphaID(time()*$id, false, 1);
    $this->db_query("UPDATE links SET link='?' WHERE id=?;", $link, $id);
}
**************************/// http://docs.amazonwebservices.com/AmazonS3/latest/dev/index.html?UploadObjSingleOpPHP.html// use REDUCED_REDUNDANCY?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head>
<title>pyf.li | Post Your Files</title>
<style type="text/css">
body {
font-family:Arial;
}

p {
font-size:20pt;
line-height:150%;
}

div#uploading,
div#failed,
div#download {
display:none;
}

div#failed p,
div#download p {
font-size:12pt;
}

div#pcent {
width:0%;
background-color:#a1bc86;
padding:3px 0px 3px 0px;
color:#baee88;
margin:0px;
overflow:visible;
text-align:right;
}

div#pcent2,
div#pbar {
width:780px;
border:solid 1px #a1bc86;
font-family:arial;
font-size:18pt;
border-radius:5px;-moz-border-radius:5px;}

div#pbar {
display:none;
}

h1 {
font-size:18pt;
font-family:Georgia;
font-style:italic;
color:#5CA766;
}

div#pcent2 {
border:none;
text-align:right;
margin-top:10px;
padding:0;
font-family:Georgia;
font-style:italic;
}

div#download_link {
width:100%;
margin-top:40px;
text-align:center;
font-size:12pt;
}

p.download_link {
width:100%;
text-align:center;
}

div#content {
width:800px;
margin-left:auto;
margin-right:auto;
}

p#share_another {
margin-top:60px;
text-align:left;
}

p#share_another a {
color:blue;
text-decoration:none;
font-size:150%;
padding:5px;border:solid 2px blue;
border-radius:5px;-moz-border-radius:5px;}

div#DEBUG {
color:red;
}

div.unavailable {
border:solid 2px #666;
border-radius:5px;-moz-border-radius:5px;width:75%;
}

div.unavailable p {
font-size:12pt;
text-align:center;
}
</style>
<script type="text/javascript" src="html5uploader.js"></script>
<script type="text/javascript" language="javascript">

//onerror = recover_error();

function create_xhr()
{
    var xhr;
    if (window.XMLHttpRequest)
        xhr = new XMLHttpRequest;
    else if (window.ActiveXObject)
    {
        try
        {
            xhr = new ActiveXObject("Microsoft.XMLHTTP");
        }
        catch (e)
        {
        }
    }
    return xhr;
}

function recover_error()
{
    var id = document.getElementById('id').value;
    if (id != '')
        update_progress();
}

var first_time = true;
function update_progress()
{
    var xhr = create_xhr();
    var id = document.getElementById('id').value;
    xhr.open('GET', './?query_progress='+id, true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4)
        {
            var success  = false;
            var finished = false;
            var fname = document.getElementById('file').value.match(/[^\/\\]+$/);
            if (xhr.status == 200)
            {
                document.getElementById('DEBUG').innerHTML = xhr.responseText;
                try
                {
                    var j = JSON.parse(xhr.responseText);

                    if (j.error == 0)
                    {
                        document.getElementById('pcent').style.width = j.percent_complete+'%';
                        if (j.percent_complete == 100)
                        {
                            finished = true;
                            document.getElementById('uploading').innerHTML = 0;
                            document.getElementById('pcent2').innerHTML = fname + ' upload complete.';
                            document.getElementById('share_another').innerHTML = "<a href='.'>Share another file</a>";
                        }
                        else
                            document.getElementById('pcent2').innerHTML = 'Uploading ' + fname + ' ... ' +j.percent_complete+'%';
                        document.getElementById('download').style.display = 'block';
                        document.getElementById('download_link').innerHTML = "<a href='" + j.link + "' target='_blank'>" + j.link + "</a>";

                        if (first_time)
                        {
                            document.getElementById('copy').innerHTML =
                                "<object classid='clsid:d27cdb6e-ae6d-11cf-96b8-444553540000' width='110' height='14' id='clippy'>"
                                + "<param name='movie' value='clippy.swf'/>"
                                + "<param name='allowScriptAccess' value='always' />"
                                + "<param name='quality' value='high' />"
                                + "<param name='scale' value='noscale' />"
                                + "<param name='FlashVars' value='text=" + j.link + "'>"
                                + "<param name='bgcolor' value='#44f'>"
                                + "<embed src='clippy.swf'"
                                + "width='110'"
                                + "height='14'"
                                + "name='clippy'"
                                + "quality='high'"
                                + "allowScriptAccess='always'"
                                + "type='application/x-shockwave-flash'"
                                + "pluginspage='http://www.macromedia.com/go/getflashplayer'"
                                + "FlashVars='text=" + j.link + "'"
                                + "bgcolor='#44f'"
                                + "/></object>";
                        }

                        first_time = false;
                        success = true;
                    }
                }
                catch (e)
                {
                    success = false;
                }
            }

            if (!success)
            {
                document.getElementById('pcent2').innerHTML = 'Error uploading ' + fname;
                document.getElementById('pcent2').style.color = 'red';
                document.getElementById('download').style.display = 'none';
                document.getElementById('failed').style.display = 'block';
            }

            if (success && !finished)
                setTimeout('update_progress();',1000);
        }
    };
    xhr.send();
}

function canunload()
{
    if (document.getElementById('uploading').innerHTML == 1)
        return 'Warning! Leaving this page will cancel the file sharing and the link will not work.';
}

function upload_file()
{
    set_id();
    document.getElementById('uploading').innerHTML = 1;
    document.getElementById('file_upload_form').submit();
    document.getElementById('instructions').style.display = 'none';
    document.getElementById('pbar').style.display = 'block';
    document.getElementById('pcent2').innerHTML = 'Preparing upload';
    setTimeout('update_progress();',500);
}

function set_id()
{
    var dt = new Date();
    document.getElementById('id').value = dt.valueOf() + (((1+Math.random())*0x10000)|0).toString(16).substring(1);
}

function init()
{
    document.getElementById('file_upload_form').target = 'upload_target';
    new uploader('drop', null, 'http://localhost:8089/?form=submit', null);
}
</script>
</head>

<body onload="init();" onbeforeunload="return canunload();">

<div id='content'>
<div><h1><img alt='' src='title.png' height='70' /></h1></div>
<p>Real-time file sharing.<br />Don't wait for files to upload before downloads can begin.</p>
<div id='instructions'>
<h1>How does it work?</h1>
<ol>
<li>Use the file selector below to pick which file you want to share.</li>
<li>We'll give you a URL to share with your friends to download the file. Immediately.</li>
</ol>

<?php if ($service_available) { ?>
<h1>Share a file</h1>
<form id="file_upload_form" method="post" enctype="multipart/form-data" action="http://localhost:8089/?form=submit">
<input name="id" id='id' size="27" type="text" />
<input name="file" id="file" size="27" type="file" onchange="upload_file();"/><br />
<iframe id="upload_target" style="display:none" name="upload_target" src="" style="width:800px;height:400px;border:1px solid #000;"></iframe>
</form>
<div id='drop' style="width:100px;height:100px;background-color:Red;"></div>
<?php } else { ?>
<div class='unavailable'>
<p>Sorry, the service is currently unavailable.</p>
<p>We are in Alpha Testing and it looks like we've suffered a problem. We'll fix it and restore our service as soon as possible.</p>
<p>Please check back later.</p>
</div>
<?php } ?>

</div>

<div id='pbar'><div id="pcent">&nbsp;</div></div>
<div id='pcent2'>&nbsp;</div>
<div id='download'>
<p>Share this link with your friends to download your file. There's no need to wait for the upload to finish first, they can start to download straight away !</p>
<p class='download_link'><span id='download_link'></span> <span id='copy'></span></p>
<p id='share_another'></p>
</div>
<div id='failed'>
<p>An unrecoverable error occurred uploading this file. Please try our <a href='#'>basic file uploader</a> instead.</p>
</div>
<div id='uploading'>0</div>
<div id='DEBUG'></div>
</div>
</body>
</html>
