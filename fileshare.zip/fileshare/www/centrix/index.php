<?php
require_once './library/stdhdr.php';
require_once "library/alphaID.inc.php";
require_once "config.php";
require_once 'library/database.php';

$pyfli = new pyfli;

function write_upload_form()
{
    global $pyfli_external;
	echo "<div class='_upload'>";
    echo "<form id='file_upload_form' method='post' enctype='multipart/form-data' action='$pyfli_external/?form=submit'>";
    echo "<input name='id' id='id' size='27' type='hidden' />";
    echo "<input name='file' id='file' size='27' type='file' onchange='upload_file();'/><br />";
    echo "<iframe id='upload_target' style='display:none' name='upload_target' src='' style='width:800px;height:400px;border:1px solid #000;'>";
    echo "</iframe>";
    echo "</form>";
    echo "</div>";
}

// Test the pyf.li httpd process is running
$res = curl_init($pyfli_internal);
curl_setopt($res, CURLOPT_NOBODY, true);
curl_setopt($res, CURLOPT_FOLLOWLOCATION, true);
curl_exec($res);
$service_available = (curl_getinfo($res, CURLINFO_HTTP_CODE) == 200);
curl_close($res);

// Query Progress request proxy
if (isset($_GET['query_progress']))
{
    if ($service_available)
    {
        $res = @curl_init("$pyfli_internal/?query_progress={$_GET['query_progress']}");
        @curl_setopt($res, CURLOPT_URL, "$pyfli_internal/?query_progress={$_GET['query_progress']}");
        curl_exec($res);
        @curl_close($res);
    }
    else
        echo "{\"version\":1,error:\"The service is currently unavailable.\"}";
    exit;
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Centrix Software Support powered by pyf.li</title>
<meta name="keywords" content="pyfli, pyf.li, realtime, real-time, file sharing, sharing, files, filesharing, publishing, audio, music, text, documents, cloud-based file sharing, ge.tt" />
<meta name="description" content="cloud-based real-time file sharing. no plugins, no registration, no account" />
<link rel="stylesheet" href="./main.css" type="text/css" media="screen" />
<script type="text/javascript" language="javascript" src='./pyfli.js'></script>
<style>

.upload {

          margin: 0 auto;

           width:100%;

           text-align:center;

     }

 

     .button {

           border: none;

           background: url('images/upload-up.jpg') no-repeat top left;

           width: 250px;

           height: 100px;

 

     }

 

     .button:hover {

           border: none;

           background: url('images/upload-down.jpg') no-repeat top left;

           width: 250px;

           height: 100px;

     }

</style>

</head>

<body onload="init();" onbeforeunload="return canunload();">

<div class='content'>
<div class='logo'><img alt='' src='http://www.centrixsoftware.com/wp-content/themes/centrixsoftware/images/centrix_logo.gif' height='44' /></div>

<div class='footnote'>
<p><a href='http://pyf.li'><img alt='' src='./images/pyfli.png' height='88' /></a></p>
</div>

<div class='mainpanel'>
<p style='color:#AB9F4E; font-size:140%; font-weight:bold;'><img style='float:left' width='285' src='./images/workspace.gif' />
Optimizing legacy, virtualized and Web application environments for enterprise organizations</p>
<div id='instructions'>
<h1>Customer Support</h1>
<p>Press the button below to select the file you want to send to our Support Team.</p>
</div>

<div id='progress'>
<div id='pbar'><div id="pcent">&nbsp;</div></div>
<div id='pcent2'>&nbsp;</div>
</div>

<div id='download'>
<p class='download_link'><span id='download_link'></span></p>
</div>
<div id='failed' class='unavailable'>
<p>Sorry, an unrecoverable error occurred uploading this file.</p>
<p>Please contact the Support Team at <a href='mailto:support@centrixsoftware.com'>support@centrixsoftware.com</a>.</p>
</div>

<div id='go_again'>
<?php
if ($service_available)
    write_upload_form();
else
{
    echo "<div class='unavailable'>";
    echo "<p>Sorry, the service is currently unavailable.</p>";
    echo "<p>Please contact <a href='mailto:support@centrixsoftware.com'>support@centrixsoftware.com</a>.</p>";
    echo "</div>";
}
?>
</div>

<div id='uploading'>0</div>
<div id='DEBUG'></div>
</div>
</div>

</body>
</html>
